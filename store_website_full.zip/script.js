
// بسيط: سلة محلية في localStorage
let cart = JSON.parse(localStorage.getItem('cart') || '[]');

function saveCart(){
  localStorage.setItem('cart', JSON.stringify(cart));
  renderCart();
}

function addToCart(name, price){
  cart.push({name, price, qty:1, img: ''});
  saveCart();
  alert(name + ' تمت الإضافة للسلة');
}

function renderCart(){
  const container = document.getElementById('cart-items');
  if(!container) return;
  container.innerHTML = '';
  if(cart.length === 0){
    container.innerHTML = '<p>لا يوجد منتجات بعد</p>';
    document.getElementById('total').innerText = 'الإجمالي: 0 ريال';
    return;
  }
  let total = 0;
  cart.forEach((it, idx) => {
    total += it.price * it.qty;
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
      <img src="${it.img || 'https://via.placeholder.com/150'}" alt="">
      <div style="flex:1">
        <strong>${it.name}</strong>
        <div>${it.price} ريال × <input type="number" min="1" value="${it.qty}" onchange="updateQty(${idx}, this.value)" style="width:60px"></div>
      </div>
      <button onclick="removeItem(${idx})">حذف</button>
    `;
    container.appendChild(div);
  });
  document.getElementById('total').innerText = 'الإجمالي: ' + total + ' ريال';
}

function updateQty(i, v){
  cart[i].qty = Number(v);
  saveCart();
}

function removeItem(i){
  cart.splice(i,1);
  saveCart();
}

function checkout(){
  if(cart.length === 0){ alert('السلة فارغة'); return; }
  alert('محاكاة إتمام الشراء — شكراً لكِ ❤');
  cart = [];
  saveCart();
}

// Admin add product (client-side only)
function addProduct(){
  const name = document.getElementById('p-name').value;
  const price = Number(document.getElementById('p-price').value);
  const img = document.getElementById('p-img').value;
  const adminList = document.getElementById('admin-list');
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `<img src="${img}" style="height:140px;object-fit:cover"><h3>${name}</h3><p class="price">${price} ريال</p>`;
  adminList.prepend(card);
  alert('تمت الإضافة مؤقتاً في الواجهة فقط');
}

// Render cart on load
document.addEventListener('DOMContentLoaded', function(){ renderCart(); });
